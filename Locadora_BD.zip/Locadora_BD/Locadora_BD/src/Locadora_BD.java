import java.io.IOException;
import java.sql.*;
import java.util.Scanner;


public class Locadora_BD {
     public Connection conexao = null;
           
   public Locadora_BD() {
        try{
        //Carregar driver JDBC do postgress
            Class.forName("org.postgresql.Driver");
            System.out.println("Carregou");
        } catch (ClassNotFoundException ex){ex.printStackTrace();}
    }
   
    public void setConnection() throws SQLException{
	   String host = "10.27.159.214:5432";
	   String db = "bd_trabalho";
	   String url = "jdbc:postgresql://" + host + "/" + db;
	   String user = "aluno1";
	   String senha = "aluno1";
	   conexao = DriverManager.getConnection(url, user, senha);
	   System.out.println("Criou a conexão");
   }
    public void consulta0(Connection conexao) throws SQLException{
	   String sql = "select * from locadoras.filme";
	   Statement comando = conexao.createStatement();
	   System.out.println("Exibe todos os campos da tabela filme: " + sql);
	   ResultSet resultado = comando.executeQuery(sql);
	   while(resultado.next()){
	      String titulo = resultado.getString(1);
	      String codigo = resultado.getString(2);
              String locadora_cnpj = resultado.getString(3);
	     System.out.println(titulo + "\t" + codigo + "\t" + locadora_cnpj);
             
	   }System.out.println("\n");	
	   comando.close();
	}
        public void consulta1(Connection conexao) throws SQLException{
	   String sql = "Select nome,max(salario) from locadoras.caixa Group by nome";
	   Statement comando = conexao.createStatement();
	   System.out.println("Exibe o nome do caixa com maior salario: " + sql);
	   ResultSet resultado = comando.executeQuery(sql);
	   while(resultado.next()){
	      String nome = resultado.getString("nome");
	     // String cpf2 = resultado.getString(1);
              double salario = resultado.getDouble(2);
	     System.out.println(nome + "\t" + salario);
	   } System.out.println("\n");	
	   comando.close();
	}

        public void consulta2(Connection conexao) throws SQLException{
	   String sql = "select * from locadoras.filme join locadoras.copia on(filme.codigo = copia.filme_codigo)";
	   Statement comando = conexao.createStatement();
	   System.out.println("Junta filme com copia pela chave estrangeira: " + sql);
	   ResultSet resultado = comando.executeQuery(sql);
	   while(resultado.next()){
	      String s1 = resultado.getString(1);
	      String s2 = resultado.getString(2);
              String s3 = resultado.getString(3);
              String s4 = resultado.getString(4);
              String s5 = resultado.getString(5);
              int q = resultado.getInt(6);
              String s7 = resultado.getString(7);
              String s8 = resultado.getString(8);
              double salario = resultado.getDouble(2);
	     System.out.println(s1 + "\t" + s2+ "\t" + s3 + "\t" + s4 + "\t" + s5
             + "\t" + q + "\t" + s7 + "\t" + s8);
	   }System.out.println("\n");
	   comando.close();
	}
        
        public void consulta3(Connection conexao) throws SQLException{
	   String sql = "select filme_titulo,quantidade from locadoras.copia Group by filme_titulo, quantidade having quantidade > 2";
	   Statement comando = conexao.createStatement();
	   System.out.println("Exibe filmes com quantidade de copias superior a 2: " + sql);
	   ResultSet resultado = comando.executeQuery(sql);
	   while(resultado.next()){
	      String s1 = resultado.getString(1);
	      int q = resultado.getInt(2);
	     System.out.println(s1 + "\t" + q);
	   }System.out.println("\n");	
	   comando.close();
	}
        public void consulta4(Connection conexao) throws SQLException{
	   String sql = "select * from locadoras.telefone_titular  join locadoras.emails_titular using (titular_cliente_cpf) NATURAL JOIN locadoras.titular order by nome";
	   Statement comando = conexao.createStatement();
	   System.out.println("Junta as tabelas titular com o telefone dele e os emails: " + sql);
	   ResultSet resultado = comando.executeQuery(sql);
	   while(resultado.next()){
	      String s1 = resultado.getString(1);
              String s2 = resultado.getString(2);
              String s3 = resultado.getString(3);
              String s4 = resultado.getString(4);
              String s5 = resultado.getString(5);
              String s6 = resultado.getString(6);
              String s7 = resultado.getString(7);
              String s8 = resultado.getString(8);
              String s9 = resultado.getString(9);
              String s10 = resultado.getString(10);
              
	      
	     System.out.println(s1 + "\t" + s2 + "\t" + s3 + "\t" + s4 + "\t" 
                     + s5 + "\t" + s6 + "\t" + s7 + "\t" + s8 + "\t" + s9 + "\t" + s10);
	   }System.out.println("\n");	
	   comando.close();
	}
        public void consulta5(Connection conexao) throws SQLException{
	   String sql = "select * from locadoras.dependente d right outer join locadoras.titular t on (d.cliente_cpf = t.cliente_cpf) where cpfdp is null";
	   Statement comando = conexao.createStatement();
	   System.out.println("Lista titulares que não possuem dependentes: " + sql);
	   ResultSet resultado = comando.executeQuery(sql);
	   while(resultado.next()){
	        String s1 = resultado.getString(1);
              String s2 = resultado.getString(2);
              String s3 = resultado.getString(3);
              String s4 = resultado.getString(4);
              String s5 = resultado.getString(5);
              String s6 = resultado.getString(6);
              String s7 = resultado.getString(7);
	   System.out.println(s1 + "\t" + s2 + "\t" + s3 + "\t" + s4 + "\t" 
                     + s5 + "\t" + s6 + "\t" + s7);
	   }System.out.println("\n");	
	   comando.close();
	}
    public void consulta6(Connection conexao) throws SQLException{
	   String sql = "select id from locadoras.emprestimo where cliente_cpf like '%6'";
	   Statement comando = conexao.createStatement();
	   System.out.println("Exibe o id dos emprestimos feitos pelos clientes de cpf com fim 6: " + sql);
	   ResultSet resultado = comando.executeQuery(sql);
	   while(resultado.next()){
	      String id = resultado.getString(1);
	     
	     System.out.println(id + "\t");
	   }System.out.println("\n");	
	   comando.close();
	}
    

    public static void main(String[] args) {
      Locadora_BD locadora1 = new Locadora_BD();
      try{
        locadora1.setConnection();
        int n = -1;
        while(n != 0){
          System.out.println("LOCADORAS_BD");
          System.out.println("(1) Exibir todos os campos da tabela filme");
          System.out.println("(2) Exibir o nome do caixa com maior salario");
          System.out.println("(3) Juntar filme com copia pela chave estrangeira");
          System.out.println("(4) Exibir filmes com quantidade de copias superior a 2");
          System.out.println("(5) Juntar as tabelas titular com o telefone dele e os emails");
          System.out.println("(6) Lista titulares que não possuem dependentes");
          System.out.println("(7) Exibe o id dos emprestimos feitos pelos clientes de cpf com fim 6");
          System.out.println("(0) Sair");
          System.out.print("Digite um número correspondente à uma consulta: ");
          Scanner s = new Scanner( System.in );
          n = s.nextInt();
            switch (n) {
                case 1:
                    locadora1.consulta0(locadora1.conexao);
                    break;
                case 2:
                    locadora1.consulta1(locadora1.conexao);
                    break;
                case 3:
                    locadora1.consulta2(locadora1.conexao);
                    break;
                case 4:
                    locadora1.consulta3(locadora1.conexao);
                    break;
                case 5:
                    locadora1.consulta4(locadora1.conexao);
                    break;
                case 6:
                    locadora1.consulta5(locadora1.conexao);
                    break;
                case 7:
                    locadora1.consulta6(locadora1.conexao);
                    break;
                case 0:
                    System.out.println("Obrigado pela preferência !");
                    break;
                default:
                    System.out.println("Insira um número correspondente a uma uma consulta !");
                    break;
            }
            if( n != 0 ){    
                try { 
                    System.out.print("Pressione Enter para continuar...");
                    System.in.read();
                } catch (IOException ex) {
                }
            }
        }
        } catch(SQLException ex) {ex.printStackTrace();}
    }

}
